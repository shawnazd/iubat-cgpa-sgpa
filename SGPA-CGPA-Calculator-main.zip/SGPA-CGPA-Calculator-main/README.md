# SGPA-CGPA-Calculator
A Simple Calculator which finds SGPA(s) and CGPA for subjects in UG or PG degrees

The purpose of the program is to not just calculate SGPA(s) and CGPA, but its to apply python concepts such as,

 - Data structures
 - Contional Statements
 - Loops
 - Classes
 - Functions

This is one of the best ways to check out how much one can try and use the above stated concepts in a simple manner.

This calculator follows the formula,

![Image of the sgpa_cgpa_formula](https://github.com/nishanthshastry/SGPA-CGPA-Calculator/blob/main/sgpa_cgpa_formula.png)
